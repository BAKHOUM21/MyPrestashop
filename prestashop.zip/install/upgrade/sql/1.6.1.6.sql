SET NAMES 'utf8';

ALTER TABLE `PREFIX_cart_product` CHANGE `id_product_attribute` `id_product_attribute` int(10) unsigned NOT NULL DEFAULT '0';
