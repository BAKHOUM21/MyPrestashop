SET NAMES 'utf8';

INSERT INTO `PREFIX_hook` (`name`, `title`, `description`, `position`) VALUES ('displayCartExtraProductActions', 'Extra buttons in shopping cart', 'This hook adds extra buttons to the product lines, in the shopping cart', 0);
